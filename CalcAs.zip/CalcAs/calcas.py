import tkinter as tk
from tkinter import ttk, messagebox
import math

class SuperCalculator:
    def __init__(self, root):
        self.root = root
        self.root.title("CalcAs 0.10")
        self.root.geometry("500x600")
        
        # Пробуем загрузить иконку
        try:
            self.root.iconbitmap("icons/calculator.ico")  # Для .ico файла
            # Или для PNG:
            # icon = tk.PhotoImage(file="icons/calculator.png")
            # self.root.iconphoto(True, icon)
        except Exception as e:
            print(f"Не удалось загрузить иконку: {e}")  # Сообщение в консоль для отладки
        
        # Переменные
        self.current_input = ""
        self.history = []
        self.result_var = tk.StringVar()
        self.result_var.set("0")
        
        # Настройка стилей
        self.setup_styles()
        
        # Главная панель
        self.setup_main_panel()
        
        # Панель инструментов (доп. функции)
        self.setup_toolbar()
        
        # Панель задач (история)
        self.setup_history_panel()

    def setup_styles(self):
        # Стили для кнопок и виджетов
        style = ttk.Style()
        style.configure("TButton", font=('Arial', 12), padding=5)
        style.configure("TLabel", font=('Arial', 14))
        
    def setup_main_panel(self):
        # Поле ввода
        entry_frame = ttk.Frame(self.root)
        entry_frame.pack(pady=10, padx=10, fill="x")
        
        self.entry = ttk.Entry(
            entry_frame, textvariable=self.result_var, font=('Arial', 24),
            justify="right", state="readonly"
        )
        self.entry.pack(fill="x")
        
        # Кнопки (цифры и основные операции)
        buttons = [
            ('7', '8', '9', '/', '√'),
            ('4', '5', '6', '*', '^'),
            ('1', '2', '3', '-', 'sin'),
            ('C', '0', '=', '+', 'cos')
        ]
        
        for row in buttons:
            frame = ttk.Frame(self.root)
            frame.pack(fill="x", padx=5, pady=2)
            for btn in row:
                ttk.Button(
                    frame, text=btn, width=5,
                    command=lambda b=btn: self.on_button_click(b)
                ).pack(side="left", expand=True)
    
    def setup_toolbar(self):
        # Дополнительные функции (π, e, скобки)
        toolbar = ttk.Frame(self.root)
        toolbar.pack(fill="x", padx=5, pady=5)
        
        extra_buttons = ['π', 'e', '(', ')', 'log', 'tan']
        for btn in extra_buttons:
            ttk.Button(
                toolbar, text=btn, width=6,
                command=lambda b=btn: self.on_button_click(b)
            ).pack(side="left", padx=2)
    
    def setup_history_panel(self):
        # История вычислений
        history_frame = ttk.LabelFrame(self.root, text="История", padding=10)
        history_frame.pack(fill="both", expand=True, padx=10, pady=5)
        
        self.history_list = tk.Listbox(
            history_frame, font=('Arial', 10), height=5
        )
        self.history_list.pack(fill="both", expand=True)
        
        # Кнопка очистки истории
        ttk.Button(
            history_frame, text="Очистить историю",
            command=self.clear_history
        ).pack(pady=5)
    
    def on_button_click(self, button):
        if button == "C":
            self.current_input = ""
            self.result_var.set("0")
        elif button == "=":
            self.calculate_result()
        elif button == "√":
            self.current_input += "math.sqrt("
            self.result_var.set(self.current_input)
        elif button == "^":
            self.current_input += "**"
            self.result_var.set(self.current_input)
        elif button == "π":
            self.current_input += "math.pi"
            self.result_var.set(self.current_input)
        elif button == "e":
            self.current_input += "math.e"
            self.result_var.set(self.current_input)
        elif button in ("sin", "cos", "tan", "log"):
            self.current_input += f"math.{button}("
            self.result_var.set(self.current_input)
        else:
            self.current_input += button
            self.result_var.set(self.current_input)
    
    def calculate_result(self):
        try:
            result = eval(self.current_input, {"math": math})
            self.history.append(f"{self.current_input} = {result}")
            self.history_list.insert(tk.END, self.history[-1])
            self.result_var.set(result)
            self.current_input = str(result)
        except Exception as e:
            messagebox.showerror("Ошибка", f"Неверное выражение: {e}")
            self.current_input = ""
            self.result_var.set("0")
    
    def clear_history(self):
        self.history_list.delete(0, tk.END)
        self.history.clear()

if __name__ == "__main__":
    root = tk.Tk()
    app = SuperCalculator(root)
    root.mainloop()